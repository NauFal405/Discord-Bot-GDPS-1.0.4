<?php
//Emoji Code 
//To Get Emoji Code
//For Android ( :- + Emoji )
//For PC ( / + Emoji )

$stars = "<:stars:652510817740259337>";
$CP = "<:CP:652872496231743508>";
$goldCoins = "<:gCoins:653899110486900747>";
$coins = "<:usercoins:652864078708211712>";
$unverifycoin = "<:uncoins:655602598061015074>";
$demon = "<:angry_face:652863860855799839>";
$like = "<:like:648688145063477267>";
$YT = "<:yt:652510641936007168>";
$twitter = "<:twitter:652510916822433834>";
$twitch = "<:twitch:653541948291809280>";
$play = "<:dl:653046476158533670>";
$download = "<:dls:653062148062314525>";
$lengthlvl = "<:length:654108484324950016>";

//For See Diff Level Its Already set In Bot Files
?>